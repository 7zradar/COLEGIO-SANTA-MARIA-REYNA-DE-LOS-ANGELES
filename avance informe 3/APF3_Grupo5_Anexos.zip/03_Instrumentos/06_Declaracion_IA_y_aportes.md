# Declaración de apoyo de IA y aportes del equipo

Material preparado el 02/11/2026 con apoyo de Codex. La IA ayudó a revisar la consigna, inspeccionar código, redactar el borrador, programar mejoras y crear documentos, hojas, presentación e importador para Figma. La redacción inicial y la preparación de estos artefactos tienen apoyo extenso de IA. No se ha medido un porcentaje de autoría humana y no se declara que el aporte de IA sea inferior al 30%.

La consigna establece una penalización de cinco puntos si el contenido de IA supera el 30%. El equipo debe revisar esa regla con el docente, elaborar su análisis propio a partir de las evidencias y documentar los aportes efectivos. Cambiar palabras o eliminar esta declaración no acredita autoría ni reduce por sí solo el aporte utilizado.

Las capturas y JSON técnicos proceden de la revisión del proyecto. Las cinco sesiones APF3 no se han realizado. No se generaron participantes, consentimientos, resultados SEQ/SUS ni citas de usuarios. Los datos APF2 se conservan como línea base del informe suministrado por el equipo.

## Registro de elaboración propia por completar con hechos
| Integrante | Aporte efectivo | Archivo y versión | Evidencia de revisión | Fecha |
|---|---|---|---|---|
| Víctor Jesús Chávez Díaz | | | | |
| Bruno Nicolás Guerra Quispe | | | | |
| Leonardo Francisco León Soles | | | | |
| Emerson Junior Mendoza Ventura | | | | |

## Coevaluación
Cada integrante registra qué entregó, cómo verificó sus decisiones y qué revisó de otro integrante. Acordar el factor de contribución con evidencia real; no preasignar 1,0 a todas las personas. Conservar historial de edición, actas de ensayo y tareas efectivamente resueltas.
