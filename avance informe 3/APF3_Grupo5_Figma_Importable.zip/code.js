// Figma development plugin. Creates a new APF3 set without deleting existing pages.
figma.showUI(__html__, {width:460,height:400});
figma.ui.onmessage=async function(msg){
 if(msg.type!=='build')return;
 try{
  await figma.loadFontAsync({family:'Inter',style:'Regular'});
  await figma.loadFontAsync({family:'Inter',style:'Bold'});
  const bundle=msg.bundle, images={};
  for(const name of Object.keys(bundle.images))images[name]=figma.createImage(new Uint8Array(bundle.images[name])).hash;
  const pages={};
  for(const name of bundle.pages){const p=figma.createPage();p.name=name;pages[name]=p;}
  const standard={background:'#FFFFFF',surface:'#F7F5F1',ink:'#202D3A',muted:'#505B67',accent:'#7B1F36',onAccent:'#FFFFFF',border:'#64707D',focus:'#005FCC',error:'#A3213C'};
  const high={background:'#000000',surface:'#000000',ink:'#FFFFFF',muted:'#FFFFFF',accent:'#FFE66D',onAccent:'#000000',border:'#FFFFFF',focus:'#00FFFF',error:'#FFE66D'};
  function rgb(hex){return {r:parseInt(hex.slice(1,3),16)/255,g:parseInt(hex.slice(3,5),16)/255,b:parseInt(hex.slice(5,7),16)/255};}
  const col=figma.variables.createVariableCollection('Santa María APF3');
  const standardMode=col.modes[0].modeId;col.renameMode(standardMode,'Estándar');let highMode=null;
  try{highMode=col.addMode('Alto contraste');}catch(e){figma.notify('El plan no admite un segundo modo. Se conservan estilos y pantallas de alto contraste.');}
  const vars={};
  for(const k of Object.keys(standard)){const v=figma.variables.createVariable(k,col,'COLOR');v.setValueForMode(standardMode,rgb(standard[k]));if(highMode)v.setValueForMode(highMode,rgb(high[k]));vars[k]=v;}
  function paint(k,hc=false){let a={type:'SOLID',color:rgb((hc?high:standard)[k]||k)};if(!hc&&vars[k])a=figma.variables.setBoundVariableForPaint(a,'color',vars[k]);return a;}
  const textStyles={};
  for(const [name,size,bold]of [['Título',48,true],['Subtítulo',32,true],['Sección',24,true],['Cuerpo',20,false],['Etiqueta',18,true],['Ayuda',16,false]]){
   const st=figma.createTextStyle();st.name='APF3/'+name;st.fontName={family:'Inter',style:bold?'Bold':'Regular'};st.fontSize=size;st.lineHeight={unit:'PERCENT',value:145};textStyles[size+':'+bold]=st.id;
  }
  function rect(parent,x,y,w,h,k='background',hc=false){const n=figma.createRectangle();parent.appendChild(n);n.x=x;n.y=y;n.resize(w,h);n.fills=[paint(k,hc)];return n;}
  const styleJobs=[];
  function txt(parent,t,x,y,w,size=20,bold=false,k='ink',hc=false){const n=figma.createText();parent.appendChild(n);n.fontName={family:'Inter',style:bold?'Bold':'Regular'};n.fontSize=size;n.lineHeight={unit:'PERCENT',value:145};n.characters=t;n.resize(w,30);n.textAutoResize='HEIGHT';n.x=x;n.y=y;n.fills=[paint(k,hc)];n.name=t.slice(0,55);if(textStyles[size+':'+bold])styleJobs.push(n.setTextStyleIdAsync(textStyles[size+':'+bold]));return n;}
  function frame(parent,name,x=0,y=0,w=1440,h=1250,hc=false){const f=figma.createFrame();parent.appendChild(f);f.name=name;f.resize(w,h);f.x=x;f.y=y;f.fills=[paint('background',hc)];f.clipsContent=true;if(hc&&highMode)f.setExplicitVariableModeForCollection(col,highMode);return f;}
  function photo(parent,name,x,y,w,h){const n=rect(parent,x,y,w,h,'surface');n.name='Imagen '+name;n.fills=[{type:'IMAGE',imageHash:images[name],scaleMode:'FILL'}];n.cornerRadius=10;return n;}
  const todo=[];
  function link(node,destination){node.setPluginData('apf3Target',destination);todo.push([node,destination]);}
  function button(parent,t,x,y,w=240,target=null,hc=false){const n=frame(parent,'Botón '+t,x,y,w,56,hc);n.cornerRadius=6;n.fills=[paint('accent',hc)];txt(n,t,18,13,w-36,18,true,'onAccent',hc);n.setPluginData('role','button');n.setPluginData('accessibleName',t);if(target)link(n,target);return n;}
  function field(parent,label,value,x,y,w=560,error='',hc=false,large=false){const scale=large?1.35:1;txt(parent,label,x,y,w,18*scale,true,'ink',hc);const n=rect(parent,x,y+35*scale,w,58*scale,'background',hc);n.cornerRadius=4;n.strokes=[paint(error?'error':'border',hc)];n.strokeWeight=2;txt(parent,value||'Escribe aquí',x+16,y+47*scale,w-32,20*scale,false,value?'ink':'muted',hc);n.name='Campo '+label;n.setPluginData('role','textbox');n.setPluginData('label',label);if(error)txt(parent,error,x,y+100*scale,w,16*scale,false,'error',hc);return n;}
  await figma.setCurrentPageAsync(pages['03 Kit accesible']);
  const kit=pages['03 Kit accesible'];txt(kit,'Kit accesible Santa María',0,0,1450,48,true);
  txt(kit,'Variables con modos estándar y alto contraste. Inter 16–48 px. Escala de espaciado 8, 16, 24, 32, 48 y 64 px.',0,85,1450);
  let ci=0;for(const k of Object.keys(standard)){const x=(ci%5)*290,y=165+Math.floor(ci/5)*140;rect(kit,x,y,240,68,k);txt(kit,k+' '+standard[k],x,y+76,270,16);ci++;}
  const states=['normal','hover','focus','active','disabled','error'];
  const comps=[];
  for(const [i,state]of states.entries()){
   const comp=figma.createComponent();kit.appendChild(comp);comp.name='Estado='+state;comp.resize(255,66);comp.x=(i%3)*300;comp.y=510+Math.floor(i/3)*125;comp.cornerRadius=6;comp.fills=[paint(state==='disabled'?'surface':'accent')];
   if(state==='hover')comp.opacity=.92;if(state==='active')comp.opacity=.82;
   if(state==='focus'){comp.strokes=[paint('focus')];comp.strokeWeight=3;comp.strokeAlign='OUTSIDE';}
   if(state==='error'){comp.strokes=[paint('error')];comp.strokeWeight=3;}
   txt(comp,'Registrar consulta',18,18,220,18,true,state==='disabled'?'muted':'onAccent');comp.description='Botón '+state+'. Área mínima 44×44. Nombre igual al texto. Foco exterior visible.';comps.push(comp);
  }
  const set=figma.combineAsVariants(comps,kit);set.name='APF3/Botón';set.x=0;set.y=510;set.description='Seis estados. Mantener nombre visible y destino explícito. WCAG 2.5.3 y 2.4.7.';
  const inputs=[];for(const [i,state]of states.entries()){
   const comp=figma.createComponent();kit.appendChild(comp);comp.name='Estado='+state;comp.resize(550,165);comp.x=(i%2)*600;comp.y=900+Math.floor(i/2)*210;comp.fills=[paint('background')];
   field(comp,'Correo electrónico','prueba@example.com',8,5,530,state==='error'?'Escribe un correo con nombre y dominio.':'');
   if(state==='focus'){comp.strokes=[paint('focus')];comp.strokeWeight=3;}
   if(state==='disabled')comp.opacity=.6;inputs.push(comp);
  }
  const iset=figma.combineAsVariants(inputs,kit);iset.name='APF3/Campo';iset.x=0;iset.y=860;iset.description='Etiqueta visible, ayuda y error relacionados. En HTML usar for/id, autocomplete=email y aria-describedby.';
  txt(kit,'Escala de tipografía y regla de contraste',0,1640,1400,32,true);
  txt(kit,'Texto normal ≥4,5:1. Texto grande ≥3:1. Componentes e indicadores esenciales ≥3:1. No depender solo del color.',0,1705,1400);
  txt(kit,'Los estados son especificaciones de diseño. Los anuncios, el orden de teclado y la semántica se validan en HTML con tecnología real.',0,1790,1400);

  const targets={};
  function shell(page,key,title,x,y,hc=false,large=false){const f=frame(page,key,x,y,1440,1250,hc);const nav=['inicio','primaria','galeria','contacto','ingreso'];
   rect(f,0,0,1440,52,'surface',hc);txt(f,'Preferencias de lectura',65,13,300,16,true,'ink',hc);button(f,'Alto contraste',845,0,225,'hc-'+key,hc);button(f,'Texto ampliado',1090,0,255,'lg-'+key,hc);
   photo(f,'logo.png',65,80,48,60);txt(f,'Santa María',130,74,390,32,true,'ink',hc);txt(f,'Reyna de los Ángeles',130,119,390,16,false,'muted',hc);
   for(const [i,k]of nav.entries()){const labels={inicio:'Inicio',primaria:'Primaria',galeria:'Galería',contacto:'Contacto',ingreso:'Intranet'};const t=txt(f,labels[k],670+i*140,100,135,18,true,'accent',hc);link(t,k);}
   rect(f,0,174,1440,1,'border',hc);const cr=txt(f,'Inicio',65,204,180,16,false,'accent',hc);cr.textDecoration='UNDERLINE';link(cr,'inicio');
   txt(f,title,65,258,1280,large?60:48,true,'ink',hc);
   rect(f,0,1135,1440,115,'surface',hc);txt(f,'Prototipo académico de demostración · Grupo 5',65,1160,1000,18,false,'ink',hc);txt(f,'Accesibilidad parcial · WCAG 2.1 AA como objetivo',65,1195,1200,16,false,'muted',hc);
   targets[(hc?'hc-':large?'lg-':'')+key]=f;return f;}
  function content(f,key,hc=false,large=false,state='normal'){
   if(key==='inicio'){
    txt(f,'Aprendemos hoy.\nCrecemos para la vida.',65,390,605,large?60:52,true,'accent',hc);
    txt(f,'Una educación que une conocimiento, valores y acompañamiento para cada etapa escolar.',65,590,570,large?27:23,false,'muted',hc);
    button(f,'Conoce Primaria',65,755,270,'primaria',hc);button(f,'Solicitar información',355,755,290,'contacto',hc);photo(f,'foto1.jpg',745,380,625,500);
    txt(f,'Inicial, Primaria y Secundaria',65,905,1000,24,true,'ink',hc);
   }else if(key==='primaria'){
    txt(f,'Aprender a descubrir y convivir',65,355,1000,large?38:32,true,'ink',hc);
    const a=[['01','Aprendizaje significativo','Relacionamos lo aprendido con experiencias cercanas.'],['02','Creatividad e interacción','Exploramos ideas y trabajamos en equipo.'],['03','Familias presentes','Acompañamos el proceso junto a las familias.']];
    a.forEach((z,i)=>{const yy=460+i*175;txt(f,z[0],65,yy,100,40,true,'accent',hc);txt(f,z[1],190,yy,1110,large?30:26,true,'ink',hc);txt(f,z[2],190,yy+53,1110,large?27:22,false,'muted',hc);});button(f,'Consultar sobre Primaria',65,1010,360,'contacto',hc);
   }else if(key==='galeria'){
    txt(f,'Experiencias de nuestra comunidad',65,355,1280,large?32:24,false,'muted',hc);
    ['foto1.jpg','foto2.jpg','foto3.jpg','foto12.jpg','foto13.jpg','foto22.jpg'].forEach((z,i)=>{const x=65+(i%3)*440,y=445+Math.floor(i/3)*315;const ph=photo(f,z,x,y,410,235);link(ph,'galeria-modal');const t=txt(f,['Compartimos en comunidad','Aprendemos juntos','Celebramos nuestros logros'][i%3],x,y+250,410,large?23:18,true,'ink',hc);link(t,'galeria-modal');});
   }else if(key==='contacto'){
    txt(f,'Completa tu consulta',65,355,1250,large?34:28,true,'ink',hc);txt(f,'Paso 1 de 2. Los campos con asterisco son obligatorios.',65,410,1250,large?27:20,false,'muted',hc);
    let off=0;if(state==='error'){rect(f,65,455,1300,100,'surface',hc);txt(f,'Revisa 1 error antes de continuar',88,465,1200,22,true,'error',hc);const er=txt(f,'Correo electrónico: escribe un formato válido.',88,505,1200,18,false,'accent',hc);er.textDecoration='UNDERLINE';link(er,'contacto-corregido');off=100;}
    const xx=65,yy=470+off,sp=large?180:state==='error'?155:145;
    field(f,'Nombre completo *',state==='normal'?'':'Prueba Grupo 5',xx,yy,620,'',hc,large);
    field(f,'Correo electrónico *',state==='error'?'prueba@':state==='normal'?'':'prueba@example.com',745,yy,620,state==='error'?'Escribe un correo con nombre y dominio.':'',hc,large);
    field(f,'Teléfono opcional',state==='normal'?'':'900 000 000',xx,yy+sp,620,'',hc,large);
    const motive=field(f,'Motivo de consulta *',state==='normal'?'Selecciona una opción':'Primaria',745,yy+sp,620,'',hc,large);link(motive,'contacto-corregido');
    field(f,'Mensaje *',state==='normal'?'':'Deseo información sobre Primaria.',xx,yy+2*sp,1300,'',hc,large);
    const ack=yy+2*sp+(large?155:115);rect(f,65,ack,24,24,'background',hc).strokes=[paint('border',hc)];txt(f,'Usaré datos ficticios en este piloto académico.',105,ack-3,1200,large?24:18,false,'ink',hc);
    button(f,state==='normal'?'Revisar consulta':'Continuar a revisión',65,ack+60,325,state==='normal'?'contacto-error':'contacto-revision',hc);
    if(state==='normal')button(f,'Ver ejemplo completado',430,ack+60,355,'contacto-corregido',hc);
   }else if(key==='ingreso'){
    txt(f,'Accede a la intranet académica',65,355,1250,32,true,'ink',hc);field(f,'Usuario','ana',350,465,700,'',hc,large);field(f,'Contraseña','••••••••••••',350,650,700,'',hc,large);button(f,'Ingresar',350,860,700,'ingreso-error',hc);txt(f,'Cuentas de demostración. Usa la web local para operar con datos.',350,970,800,20,false,'muted',hc);
   }
  }
  await figma.setCurrentPageAsync(pages['02 Después v3']);const after=pages['02 Después v3'];
  const keys=['inicio','primaria','galeria','contacto','ingreso'], titles=['Aprendemos en comunidad','Educación Primaria','Galería de actividades','Conversemos','Intranet Santa María'];
  keys.forEach((k,i)=>{const f=shell(after,k,titles[i],i*1540,0);content(f,k);});
  for(const [i,state]of ['error','corregido'].entries()){const f=shell(after,'contacto-'+state,'Conversemos',i*1540,1400);content(f,'contacto',false,false,state);}
  function stateFrame(key,title,x,y){const f=shell(after,key,title,x,y);return f;}
  const rev=stateFrame('contacto-revision','Revisa antes de registrar',3080,1400);
  txt(rev,'Paso 2 de 2',65,355,1100,24,true);txt(rev,'Nombre: Prueba Grupo 5\nCorreo: prueba@example.com\nTeléfono: 900 000 000\nMotivo: Primaria\nMensaje: Deseo información sobre Primaria.',65,440,1250,28);button(rev,'Confirmar registro',65,900,350,'contacto-confirmacion');button(rev,'Volver a editar',445,900,310,'contacto-corregido');
  const success=stateFrame('contacto-confirmacion','Tu consulta está registrada',4620,1400);txt(success,'Demostración del estado de confirmación',65,385,1250,30,true);txt(success,'En la web el servidor devuelve un código real del piloto. Este estado de Figma muestra la apariencia de la confirmación y no envía información.',65,490,1250,27);button(success,'Registrar otra consulta',65,750,370,'contacto');button(success,'Volver al inicio',465,750,300,'inicio');
  const gm=stateFrame('galeria-modal','Compartimos en comunidad',6160,1400);photo(gm,'foto1.jpg',195,370,1050,560);button(gm,'Cerrar ventana',540,1000,360,'galeria');
  const load=stateFrame('contacto-carga','Registrando tu consulta',0,2800);txt(load,'Espera mientras guardamos los datos. No vuelvas a enviar el formulario.',65,420,1250,28);button(load,'Ver respuesta de demostración',65,720,500,'contacto-confirmacion');
  const err=stateFrame('contacto-servidor','No pudimos guardar la consulta',1540,2800);txt(err,'Tus datos permanecen disponibles. Revisa la conexión e inténtalo de nuevo.',65,420,1250,28);button(err,'Volver a revisar',65,720,350,'contacto-revision');
  const empty=stateFrame('galeria-vacia','No hay fotos en esta categoría',3080,2800);txt(empty,'Prueba otra categoría para explorar las actividades del colegio.',65,420,1250,28);button(empty,'Ver todas las actividades',65,720,430,'galeria');
  const loginerr=stateFrame('ingreso-error','Revisa tus credenciales',4620,2800);txt(loginerr,'El usuario o la contraseña no coinciden. Comprueba los datos de demostración.',65,420,1250,28);button(loginerr,'Volver a intentar',65,720,350,'ingreso');

  await figma.setCurrentPageAsync(pages['01 Antes v2']);const before=pages['01 Antes v2'];
  keys.forEach((k,i)=>{const f=frame(before,'v2 '+titles[i],i*1540,0,1440,1000);photo(f,'V2-'+(k==='ingreso'?'intranet':k)+'-normal.png',0,0,1440,810);txt(f,'Captura propia de la línea base pública reproducida localmente. Fuente: axe-V2-'+(k==='ingreso'?'intranet':k)+'.json.',32,850,1360,20);});

  await figma.setCurrentPageAsync(pages['04 Anotaciones']);const ann=pages['04 Anotaciones'];
  txt(ann,'Anotaciones para diseño e implementación',0,0,1550,48,true);
  const annotations=[
   ['Lectura y foco del portal','Orden: preferencias, marca, navegación, ruta, h1, contenido, acciones y pie. Saltar al contenido precede navegación. Al cambiar de ruta enfocar h1. WCAG 1.3.2, 2.4.1, 2.4.2 y 2.4.3.'],
   ['Nombres y funciones','Enlaces navegan. Botones ejecutan acciones. Nombre accesible incluye el texto visible. No sustituir texto por aria-label incongruente. Campos con label for/id, requerido y autocomplete. WCAG 1.3.5, 2.5.3 y 4.1.2.'],
   ['Galería y modal','Fotografía: alternativa contextual. Nombre visible Compartimos en comunidad. Abrir con Enter. Foco inicial Cerrar ventana. Tab y Mayús+Tab contenidos. Escape cierra y devuelve foco al origen. WCAG 2.1.1, 2.1.2, 2.4.3.'],
   ['Formulario y recuperación','Orden: nombre, correo, teléfono, motivo, mensaje, revisar. Error: resumen enfocado, enlaces a campos, aria-invalid y aria-describedby. Causa y sugerencia específicas. WCAG 3.3.1, 3.3.2, 3.3.3.'],
   ['Revisión y estados','Revisar: nombre, correo, teléfono, motivo y mensaje. Confirmar o volver a editar. Estado de guardado role=status/aria-live=polite. Error de envío role=alert. No anunciar mensajes decorativos. WCAG 3.3.4 y 4.1.3.'],
   ['Imágenes y verificación','Foto1: Estudiantes comparten una actividad al aire libre. Logo: Santa María Reyna de los Ángeles. Decoración: alternativa vacía en HTML. Confirmar el contexto de cada fotografía. Las anotaciones visuales no garantizan soporte de lector en Figma.'],
   ['Evidencia y estados diseñados','Cargar, error de servidor, galería vacía e ingreso inválido se incluyen como especificaciones visuales. No se presentan como capturas de ejecución web. Las capturas y JSON reales están en el ZIP.']
  ];
  annotations.forEach((a,i)=>{const f=frame(ann,a[0],(i%2)*1600,160+Math.floor(i/2)*455,1500,390);txt(f,a[0],30,30,1440,32,true);txt(f,a[1],30,100,1430,25);});

  await figma.setCurrentPageAsync(pages['05 Contraste y texto']);const variants=pages['05 Contraste y texto'];
  keys.forEach((k,i)=>{const f=shell(variants,k,titles[i],i*1540,0,true,false);content(f,k,true,false);const g=shell(variants,k,titles[i],i*1540,1400,false,true);content(g,k,false,true);});
  const mobile=frame(variants,'Contacto 320 px especificación',0,2800,320,1900);txt(mobile,'Contacto',16,40,288,32,true);txt(mobile,'Propuesta de redistribución. Validar en web a 320 px y zoom nativo.',16,105,288,18);
  ['Nombre completo','Correo electrónico','Teléfono','Motivo de consulta','Mensaje'].forEach((l,i)=>field(mobile,l,'',16,270+i*210,288));button(mobile,'Revisar',16,1450,288,'contacto-revision');

  await figma.setCurrentPageAsync(pages['00 Leyenda y resumen']);const legend=pages['00 Leyenda y resumen'];
  const cover=frame(legend,'Santa María APF3',0,0,1440,1400);txt(cover,'Santa María APF3',65,70,1250,48,true);txt(cover,'Accesibilidad universal e inclusión',65,155,1250,32,true);
  txt(cover,'Cinco pantallas, nueve ajustes principales y estados de recuperación. Prototipo visual editable generado desde los recursos del proyecto.',65,250,1250,27);
  txt(cover,'T1 Localizar dos características de Primaria\nT2 Encontrar Contacto\nT3 Reconocer Motivo de consulta\nT4 Recuperar un error, revisar y confirmar',65,420,1250,28);
  txt(cover,'Para presentar: página 02 Después v3, frame Inicio.',65,745,1250,28,true,'accent');
  txt(cover,'Leyenda',65,900,1250,32,true);txt(cover,'S Ajuste sensorial   M Ajuste motor   C Ajuste cognitivo\nOrden de lectura y foco: anotaciones en página 04\nEstándar y alto contraste: variables y página 05',65,965,1250,24);
  txt(cover,'Estado: importador preparado. El archivo, las mediciones Stark, los permisos y el enlace deben verificarse después de ejecutarlo. Sin sesiones APF3 registradas. La declaración de conformidad es parcial.',65,1170,1250,20,false,'muted');
  // Keep every live prototype destination on the same page as its trigger.
  // Page 05 remains the specification board; page 02 receives navigable copies.
  await Promise.all(styleJobs);
  for(const [i,k]of keys.entries())for(const [j,prefix]of ['hc-','lg-'].entries()){
   const copy=targets[prefix+k].clone();after.appendChild(copy);copy.x=i*1540;copy.y=4200+j*1400;copy.name=prefix+k;targets[prefix+k]=copy;
  }
  let count=0;for(const node of after.findAll(n=>!!n.getPluginData('apf3Target'))){const target=targets[node.getPluginData('apf3Target')];if(!target)continue;await node.setReactionsAsync([{trigger:{type:'ON_CLICK'},actions:[{type:'NODE',destinationId:target.id,navigation:'NAVIGATE',transition:null}]}]);count++;}
  await figma.setCurrentPageAsync(after);figma.currentPage.selection=[targets.inicio];figma.viewport.scrollAndZoomIntoView([targets.inicio]);figma.commitUndo();
  figma.ui.postMessage({type:'done',message:'Seis páginas creadas. '+count+' conexiones. Selecciona Inicio como punto inicial, prueba Presentar, mide con Stark y verifica el enlace compartido. Los estados de especificación no acreditan ejecución web.'});
 }catch(e){figma.ui.postMessage({type:'error',message:String(e.message||e)});figma.notify('No se completó la importación. Revisa el mensaje del complemento.');}
};

