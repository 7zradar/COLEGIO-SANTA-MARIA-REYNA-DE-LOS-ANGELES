# Crear el prototipo nativo de Figma

Este paquete genera seis páginas con nodos editables, variables, componentes y conexiones. No es un archivo .fig exportado ni un enlace publicado. Se verificaron la sintaxis y los recursos del importador; todavía no se ejecutó dentro de una cuenta Figma.

## Instalación
1. Entrar en una cuenta Figma y abrir un archivo de diseño vacío. Usar la aplicación de escritorio para cargar un complemento local de desarrollo.
2. En Plugins > Development crear un complemento nuevo para Figma Design con interfaz personalizada. Figma asigna su identificador real. Elegir una carpeta local del equipo.
3. Copiar `code.js` y `ui.html` de este paquete a esa carpeta. En el `manifest.json` creado por Figma conservar su `id` y usar los campos de `manifest.plantilla.json`. No inventar un identificador ni sustituirlo por el nombre del proyecto.
4. Ejecutar el complemento desde Development. Seleccionar `SantaMaria_APF3_recursos.json` y pulsar Generar páginas editables. El complemento funciona sin red y crea páginas nuevas; no borra trabajo previo.
5. Revisar las seis páginas. En 02 Después v3 seleccionar el frame Inicio como punto inicial del prototipo y asignar un nombre al flujo. Abrir Presentar y comprobar todos los enlaces.

## Páginas generadas
00 Leyenda y resumen; 01 Antes v2; 02 Después v3; 03 Kit accesible; 04 Anotaciones; 05 Contraste y texto.

Antes v2 incluye capturas reales. Después v3 incluye cinco pantallas principales y estados de contacto, galería e ingreso. Los campos del prototipo visual no aceptan escritura real. El enlace Ver ejemplo completado conduce a datos ficticios y permite explicar el flujo. Usar la web local para pruebas funcionales, teclado y lector. Los estados de carga, error de servidor, galería vacía e ingreso inválido son especificaciones de diseño, no capturas de ejecución.

## Ruta de demostración
Inicio > Primaria > Consultar sobre Primaria > Contacto. Revisar consulta conduce a un error. El enlace del error muestra el formulario corregido. Continuar a revisión > Volver a editar o Confirmar registro > Registrar otra consulta. Galería > fotografía > Cerrar ventana. Preferencias conducen a las variantes visuales.

## Comprobación del kit
Inspeccionar variables estándar y alto contraste, estilos Inter, componentes Botón y Campo con normal/hover/focus/active/disabled/error. Si el plan no permite un segundo modo, se conservan las pantallas de alto contraste y sus colores explícitos. Verificar espaciado, límites de texto grande y las anotaciones de lectura, foco, rol, nombre y alternativa. Ajustar cualquier desborde observado tras generar. El frame estrecho es una especificación, no una prueba de redistribución del navegador.

## Evidencias Stark y enlace
Ejecutar Stark sobre pares de texto/fondo y bordes relevantes. Guardar captura propia con pantalla, valores y criterio. Documentar una simulación visual como simulación. Incluir normal, focus, error y disabled. Registrar versión de Stark y fecha. No usar la simulación como sustituto de una persona con condición real.

Compartir el archivo con permiso de visualización apropiado al curso. Copiar el enlace real a la entrega y comprobarlo en incógnito, incluido el flujo Presentar. No se aporta un URL ficticio. Solo después de estas comprobaciones describir el archivo como demo Figma verificada.

## Fuentes técnicas
https://developers.figma.com/docs/plugins/manifest/
https://developers.figma.com/docs/plugins/api/figma-variables/
https://developers.figma.com/docs/plugins/api/properties/nodes-reactions/

Los complementos de desarrollo y los límites de páginas/modos dependen de la cuenta. La cuenta y el archivo final deben pertenecer al equipo. La implementación de lector de pantalla se verifica en la web y no se deduce de anotaciones de diseño.
